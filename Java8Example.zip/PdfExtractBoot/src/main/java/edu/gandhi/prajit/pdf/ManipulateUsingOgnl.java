package edu.gandhi.prajit.pdf;

import java.io.IOException;
import java.util.Map;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import edu.gandhi.prajit.pdf.pojo.PdfToPojoMapping;
import ognl.Ognl;
import ognl.OgnlException;

public class ManipulateUsingOgnl {
	public static void main(String[] args) throws JsonParseException, JsonMappingException, JsonProcessingException, IOException, OgnlException, ClassNotFoundException {
		final Map<String,Map<String,String>> metaMap=ReadExcelMetaData.readMetaExcel(ReadExcelMetaData._Excel,ReadExcelMetaData._Json);
		final ObjectMapper _Mapper = new ObjectMapper();
		Map<String,PdfToPojoMapping> valueJsonMap=_Mapper.readValue(metaMap.get("DropDownList1").get("ValueJson"),new TypeReference<Map<String,PdfToPojoMapping>>(){});
		System.out.println(valueJsonMap);
		
		for(Map.Entry<String,PdfToPojoMapping> entry:valueJsonMap.entrySet()) {
			Object enumVal=getParsedEnumValue(entry.getValue().getJavaValue());
			System.out.println(enumVal);
		}
	}
	@SuppressWarnings("unchecked")
	private static <Type> Type getParsedEnumValue(String expression) throws OgnlException {
		return (Type)Ognl.parseExpression(expression);
	}
}