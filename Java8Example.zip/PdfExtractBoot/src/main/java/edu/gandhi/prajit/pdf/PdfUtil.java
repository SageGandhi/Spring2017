package edu.gandhi.prajit.pdf;

import java.io.File;

import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.NodeList;

import com.itextpdf.forms.PdfAcroForm;
import com.itextpdf.forms.xfa.XfaForm;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfReader;

public class PdfUtil {
	private final static String Path="C:\\Users\\BatMan\\Downloads\\SSIC-CyberRiskUW2.pdf";
	public static void main(String[] args) throws Exception {
		final PdfReader pdfReader = new PdfReader(new File(Path));
		final PdfDocument pdfDocument=new PdfDocument(pdfReader);
		final PdfAcroForm pdfAcroForm=PdfAcroForm.getAcroForm(pdfDocument,true);
		pdfAcroForm.setSignatureFlag(PdfAcroForm.SIGNATURE_EXIST);
		pdfAcroForm.getFormFields().forEach((name,pdfFormField)->{
			System.out.println(name);
			System.out.println(pdfFormField.getFieldName());
			System.out.println(pdfFormField.getFormType());
		});
		if(pdfAcroForm.hasXfaForm()) {
			final XfaForm xfaForm=pdfAcroForm.getXfaForm();
			boolean printXmlDom=false;
			if(printXmlDom) {
				final Transformer transformer = TransformerFactory.newInstance().newTransformer();
				transformer.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
				transformer.setOutputProperty(OutputKeys.INDENT, "yes");
				transformer.transform(new DOMSource(xfaForm.getDomDocument()),new StreamResult(System.out));
				System.out.println(xfaForm.getDomDocument().getElementsByTagName("field").getLength());
			}
			final NodeList nodeList = xfaForm.getDomDocument().getElementsByTagName("field");
			for(int index=0;index<nodeList.getLength();index++) {
				final String key=nodeList.item(index).getAttributes().getNamedItem("name").getNodeValue();
				System.out.println("Field Key:"+key);
			}
			System.out.println(xfaForm.getDomDocument().getElementsByTagName("SignatureField1").getLength());
			System.out.println(xfaForm.getDomDocument().getElementsByTagName("OSPListDDL").getLength());
			System.out.println(xfaForm.getDomDocument().getElementsByTagName("OSPListDDL").item(0).getTextContent());
			System.out.println(xfaForm.getDomDocument().getElementsByTagName("OSPListDDL").item(1).getTextContent());
		}
		pdfDocument.close();
	}
}
