package edu.gandhi.prajit.pdf.pojo;

public enum Option {
	First,Second,Third;
}
