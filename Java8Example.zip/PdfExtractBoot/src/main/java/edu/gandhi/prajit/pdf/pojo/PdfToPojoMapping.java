package edu.gandhi.prajit.pdf.pojo;

public class PdfToPojoMapping {
	//Text Corresponding To Value In Pdf
	private String labelInPdf;
	//Value For The Text In Pdf
	private String valueInPdf;
	//Java Value For Enum
	private String javaValue;
	//To Set In Defined Pojo
	private String javaExpression;
	
	@Override
	public String toString() {
		return "PdfToPojoMapping [" + (labelInPdf != null ? "labelInPdf=" + labelInPdf + ", " : "")
				+ (valueInPdf != null ? "valueInPdf=" + valueInPdf + ", " : "")
				+ (javaValue != null ? "javaValue=" + javaValue + ", " : "")
				+ (javaExpression != null ? "javaExpression=" + javaExpression + ", " : "")
				+ "]";
	}
	/**
	 * @return the labelInPdf
	 */
	public final String getLabelInPdf() {
		return labelInPdf;
	}
	/**
	 * @param labelInPdf the labelInPdf to set
	 */
	public final void setLabelInPdf(String labelInPdf) {
		this.labelInPdf = labelInPdf;
	}
	/**
	 * @return the valueInPdf
	 */
	public final String getValueInPdf() {
		return valueInPdf;
	}
	/**
	 * @param valueInPdf the valueInPdf to set
	 */
	public final void setValueInPdf(String valueInPdf) {
		this.valueInPdf = valueInPdf;
	}
	/**
	 * @return the javaValue
	 */
	public final String getJavaValue() {
		return javaValue;
	}
	/**
	 * @param javaValue the javaValue to set
	 */
	public final void setJavaValue(String javaValue) {
		this.javaValue = javaValue;
	}
	/**
	 * @return the javaExpression
	 */
	public final String getJavaExpression() {
		return javaExpression;
	}
	/**
	 * @param javaExpression the javaExpression to set
	 */
	public final void setJavaExpression(String javaExpression) {
		this.javaExpression = javaExpression;
	}	
}