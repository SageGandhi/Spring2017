package edu.gandhi.prajit.pdf.pojo;

public class PojoToMutate {
	//Option Enum Will Be Set
	private Option option;
	/**
	 * @return the option
	 */
	public final Option getOption() {
		return option;
	}

	/**
	 * @param option the option to set
	 */
	public final void setOption(Option option) {
		this.option = option;
	}	
}