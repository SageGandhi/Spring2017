package edu.gandhi.prajit.java8.chap01;

import static java.lang.System.out;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.text.MessageFormat;
import java.util.Arrays;
import java.util.Optional;
import java.util.OptionalInt;
import java.util.TreeSet;
import java.util.function.IntBinaryOperator;
import java.util.stream.Collectors;

import edu.gandhi.prajit.java8.chap01.pojo.Product;
import edu.gandhi.prajit.java8.chap01.repo.ProductRepository;

public class AggregationOperation10 {
	private static final String Separator = "=============================================================";
	public static void main(String[] args) throws Exception {
		/**Identity Element May Not Be Present In Some Cases,In That Case Optional/OptionalInt Will Be Returned Instead Of Null.*/
		final IntBinaryOperator max=(int01,int02)->int01>int02?int01:int02;
		final OptionalInt afterReduce= Arrays.stream(new int[]{10,5,9,-45,-10}).reduce(max);
		
		/**Lazy Construction Of Exception,Only Create & Throw It If Necessary.Reduction Operation Is Terminal.*/
		out.println(afterReduce.isPresent()?afterReduce.getAsInt():afterReduce.orElseThrow(Exception::new));		
		out.println(Separator);
		
		Optional<String> minProdName=ProductRepository.getInstance().findAll().stream().map(Product::getName).filter(item->item.length()>10).min(String::compareTo);
		Optional<String> maxProdName=ProductRepository.getInstance().findAll().stream().map(Product::getName).filter(item->item.length()>10).max(String::compareTo);
		
		out.println(MessageFormat.format("Message:{0},{1}",
			minProdName.isPresent()?minProdName.get():minProdName.orElse("NotFound"),
			maxProdName.isPresent()?maxProdName.get():maxProdName.orElseThrow(Exception::new)));
		out.println(Separator);
		//Reduce Is Immutable Part Follows Functional Programming
		out.println(Arrays.stream(new int[]{10,20}).reduce(0,Integer::sum));//For Sum We Can Use Identity As 0
		out.println(Separator);
		
		//For Max Operation Identity As 0 Is Not Good Because Identity Is Compared Against Other Elements In The Stream
		out.println(Arrays.stream(new int[]{10,20}).reduce(0,Integer::max));
		out.println(Separator);
		
		out.println(Arrays.stream(new int[]{10,-20}).reduce(0,Integer::max));
		out.println(Separator);
		
		out.println(Arrays.stream(new int[]{-10,-20}).reduce(0,Integer::max));
		out.println(Separator);
		
		out.println(Arrays.stream(new int[]{}).reduce(Integer::max));
		out.println(Separator);
		//Collect Is Mutable Part Follows Object Orientation Programming
		out.println(ProductRepository.getInstance().findAll().stream().filter(product->product.getName().length()>10).map(Product::getName).collect(Collectors.joining("|")));
		//Map<PriceType,List<Products>>.No DownStream Collection
		out.println(ProductRepository.getInstance().findAll().stream().collect(Collectors.groupingBy(Product::getPrice)));
		//Using A DownStream Collection Map<PriceType,Long>
		out.println(ProductRepository.getInstance().findAll().stream().collect(Collectors.groupingBy(Product::getPrice,Collectors.counting())));
		//Using A DownStream Collection Map<PriceType,List<Product::getNameType>>		
		out.println(ProductRepository.getInstance().findAll().stream().collect(Collectors.groupingBy(Product::getPrice,Collectors.mapping(Product::getName,Collectors.toList()))));
		//Using A DownStream Collection Map<PriceType,DifferentCollectionType<Product::getNameType>>
		out.println(ProductRepository.getInstance().findAll().stream().collect(Collectors.groupingBy(Product::getPrice,Collectors.mapping(Product::getName,Collectors.toCollection(TreeSet::new)))));

		//Read A File Using Try With Resources.Resource Will Be Located Based This Current Class Location
		out.println(Separator);
		try(final BufferedReader bufferedReader=new BufferedReader(new InputStreamReader(AggregationOperation10.class.getResourceAsStream("Input.txt")))){
			bufferedReader.lines().forEach(out::println);
		}
		out.println(Separator);
	}
}