package edu.gandhi.prajit.java8.chap01;

import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class ComparatorExample03 {
	public static void main(String[] args) {
		//Using Anonymous Class
		final Comparator<String> compareByLength=new Comparator<String>() {
			@Override
			public int compare(String first, String second) {
				return Integer.compare(first.length(),second.length());
			}
		};
		List<String> firstList=Arrays.asList("*","***","****","**");
		Collections.sort(firstList,compareByLength);
		System.out.println(firstList);
		//Using Lambda:That Is Of Type Functional Interface:Only One Abstract Method
		final Comparator<String> compareByLengthLambda=(String first, String second)->
			Integer.compare(first.length(),second.length());
		List<String> secondList=Arrays.asList("*","***","****","**");
		Collections.sort(secondList,compareByLengthLambda);
		System.out.println(secondList);
		System.out.println(compareByLengthLambda.getClass());
	}
}
