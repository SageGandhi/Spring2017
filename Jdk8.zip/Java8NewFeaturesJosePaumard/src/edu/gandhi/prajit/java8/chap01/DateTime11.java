package edu.gandhi.prajit.java8.chap01;

import static java.lang.System.out;

import java.text.MessageFormat;
import java.time.DayOfWeek;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.Month;
import java.time.Period;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.time.temporal.TemporalAdjusters;
import java.util.Calendar;

public class DateTime11 {
	public static void main(String[] args) {
		final Instant startTime = Instant.now();
		final Calendar calendar = Calendar.getInstance();
		// My BirthDate,Month Is Zero Based Index
		calendar.set(1988, 01, 22, 10, 10, 10);
		out.println(calendar.getTimeInMillis());
		// Add 7 Days Time To Current Calender
		calendar.add(Calendar.DAY_OF_MONTH, 7);
		// These Calender,Date Class Are Mutable
		out.println(calendar.getTimeInMillis());
		/**
		 * Instant Class:Epoch Time Is Instant.Epoch, Instant.Min Is
		 * 1_000_000_000 Years Ago, Instant.Max Is 1_000_000_000 Years After,
		 * Instant.Now Is Current Time.Instant Class Instances Are
		 * Immutable.Precision Is Based On NanoSeconds.Differences Between
		 * Instances Is Calculated Using {@code Duration}.
		 */
		final Instant endTime = Instant.now();
		out.println(MessageFormat.format("Diff In Nano:{0},Get Nano:{1}",
				Duration.between(startTime, endTime).toNanos(), Duration.between(startTime, endTime).getNano()));
		/**
		 * SomeTimes Precision Not Important,Like Historic Event,Time For
		 * Tea-Break[Happening On The Same Day].Duration Between Two LocalDate
		 * Is Calculated Using Period.Specific Time Is Created With LocalTime
		 */
		LocalDate currentLocalDate=LocalDate.now();//Get Current LocalDate
		LocalDate shakesPeareBirthDate = LocalDate.of(1564, Month.APRIL, 23);
		out.println(MessageFormat.format(
			"Diff BetWeen 2 LocalDate:Years:{0},Days:{1},Month Relative:{2},Month Actual:{3}",
			Period.between(shakesPeareBirthDate,currentLocalDate).getYears(),
			shakesPeareBirthDate.until(currentLocalDate,ChronoUnit.DAYS),
			shakesPeareBirthDate.until(currentLocalDate).getMonths(),
			shakesPeareBirthDate.until(currentLocalDate,ChronoUnit.MONTHS)));

		//DateAdjuster Example For Both LocalDate,Will It Work For Instant As Well?
		final LocalDate nowLocalDate=LocalDate.now();
		final LocalDate nextSunday=nowLocalDate.with(TemporalAdjusters.next(DayOfWeek.SUNDAY));
		out.println(MessageFormat.format("Next Friday From Now:{0}:{1}",nowLocalDate,nextSunday));	
		
		final LocalTime nowLocalTime=LocalTime.now();
		out.println(MessageFormat.format("Time Completion Of 9 Hours:{0}",
			nowLocalTime.plusHours(3).plusMinutes(37)));//Completion Of 9 Hours		
		//Java Use TimeZone Available In https://www.iana.org/time-zones
		ZoneId.getAvailableZoneIds().stream().forEach(out::println);
		
		//Creating ZonedDateTime
		ZonedDateTime currentKolkataZoneTime=ZonedDateTime.of(LocalDateTime.of(LocalDate.now(),LocalTime.now()),ZoneId.of("Asia/Kolkata"));
		out.println(MessageFormat.format("Asia/KolkataZoneTime:{0}",currentKolkataZoneTime));
		out.println(MessageFormat.format("America/Los_AngelesZoneTime:{0}",
			currentKolkataZoneTime.withZoneSameInstant(ZoneId.of("America/Los_Angeles"))));		
		
		//DateTimeFormatter With Pre-Defined Format
		out.println(MessageFormat.format("Asia/KolkataZoneTime With Formatter DateTimeFormatter.Iso_Date_Time:{0}",
			DateTimeFormatter.ISO_DATE_TIME.format(currentKolkataZoneTime)));
		out.println(MessageFormat.format("Asia/KolkataZoneTime With Formatter DateTimeFormatter.Rfc_1123_Date_Time:{0}",
			DateTimeFormatter.RFC_1123_DATE_TIME.format(currentKolkataZoneTime)));
		
		//Api->Legacy & Legacy->Api
		final java.util.Date dateNow=new java.util.Date();
		final java.sql.Timestamp timeStampNow=new java.sql.Timestamp(dateNow.getTime());
		out.println(MessageFormat.format("java.util.Date From Instant:{0},java.util.Date To Instant:{1}",
			java.util.Date.from(Instant.now()),dateNow.toInstant()));
		out.println(MessageFormat.format("java.sql.Timestamp From Instant:{0},java.sql.Timestamp To Instant:{1}",
			java.sql.Timestamp.from(Instant.now()),timeStampNow.toInstant()));
	}
}