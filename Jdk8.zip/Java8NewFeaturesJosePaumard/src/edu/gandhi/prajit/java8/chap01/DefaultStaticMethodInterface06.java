package edu.gandhi.prajit.java8.chap01;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Predicate;

public class DefaultStaticMethodInterface06 {
	public static void main(String[] args) {
		final Predicate<String> stringLenLt20=(text01)->text01.length()<20;
		final Predicate<String> stringLenGt10=(text01)->text01.length()>10;
		final Predicate<String> stringLenBetween1020=stringLenGt10.and(stringLenLt20);
		System.out.println("Default Method In Interface:"+stringLenBetween1020.test("Prajit Gandhi"));
		
		final List<String> nameList=Arrays.asList("Prajit", "Gandhi", "Swagat", "Srichandan", "Srabani", "Ghorai",
				"Priyani", "Sarkar", "Prakash", "Chandra", "Mahato", "Ravideep", "Singh", "Supriyo", "Nath", "Suvra",
				"Majumder");
		final List<String> addIntoThisListByConsumer=new ArrayList<>();
		
		Consumer<String> sysOut=System.out::println;
		Consumer<String> addToList=addIntoThisListByConsumer::add;
		nameList.forEach(sysOut.andThen(addToList));
		
		System.out.println(addIntoThisListByConsumer);
		
		System.out.println("Static Interface Method:"+Predicate.isEqual(
			stringLenBetween1020).test(stringLenBetween1020));
	}
}