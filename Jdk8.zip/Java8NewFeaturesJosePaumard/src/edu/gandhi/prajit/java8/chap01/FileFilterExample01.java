package edu.gandhi.prajit.java8.chap01;

import java.io.File;
import java.io.FileFilter;

public class FileFilterExample01 {
	class JavaFileFilter implements FileFilter{
		@Override
		public boolean accept(File pathname) {
			return pathname.getName().endsWith(".java");
		}
	}
	public static void main(String[] args) {
		final File javaDirectory=new File("C:/Learning/JulyWs/Java8NewFeaturesJosePaumard");
		//Using Concrete Class
		System.out.println(javaDirectory.listFiles(new FileFilterExample01().new JavaFileFilter()));
		/****************************************************************************************/
		//Using Anonymous Class
		System.out.println(javaDirectory.listFiles(new FileFilter() {
			@Override
			public boolean accept(File pathname) {
				return pathname.getName().endsWith(".java");
			}
		}));
		//Lambda Expression Make Instances Of Anonymous Class Easier To Read/Write:3 Similar Implementation
		System.out.println(javaDirectory.listFiles((File pathname)->{return pathname.getName().endsWith(".java");}));
		System.out.println(javaDirectory.listFiles((File pathname)->pathname.getName().endsWith(".java")));
		System.out.println(javaDirectory.listFiles(pathname->pathname.getName().endsWith(".java")));
	}
}