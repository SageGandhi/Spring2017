package edu.gandhi.prajit.java8.chap01;

import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import edu.gandhi.prajit.java8.chap01.pojo.Product;
import edu.gandhi.prajit.java8.chap01.repo.ProductRepository;

public class FileOperation13 {
	public static void main(String[] args) throws Exception {
		final Path workSpaceThisFilePath=Paths.get("C:","Learning","JulyWs","Java8NewFeaturesJosePaumard",
			"src","edu","gandhi","prajit","java8","chap01","FileOperation13.java");
		Files.lines(workSpaceThisFilePath).forEach(System.out::println);
		
		System.out.println("========================================================================");
		
		final Path workSpaceDirPath=Paths.get("C:","Learning","JulyWs","Java8NewFeaturesJosePaumard",
				"src","edu","gandhi","prajit","java8");
		Files.list(workSpaceDirPath).filter(path->path.toFile().isDirectory()).forEach(System.out::println);
		
		System.out.println("========================================================================");
		
		final Path workSpaceDirPathInclSubDir=Paths.get("C:","Learning","JulyWs","Java8NewFeaturesJosePaumard",
				"src","edu","gandhi","prajit","java8");
		for(int depthOfExploration=0;depthOfExploration<3;depthOfExploration++){
			System.out.println("========================================================================");
			Files.walk(workSpaceDirPathInclSubDir,depthOfExploration).filter(path->path.toFile().isDirectory()).forEach(System.out::println);
			System.out.println("========================================================================");
		}
		
		System.out.println("========================================================================");
		
		final Collection<String> nameList=Arrays.asList("Prajit", "Gandhi", "Swagat", "Srichandan", "Srabani", "Ghorai","Priyani", "Sarkar", 
			"Prakash", "Chandra", "Mahato", "Ravideep", "Singh", "Supriyo", "Nath", "Suvra","Majumder");
		final List<String> nameListArray=new ArrayList<>(nameList);
		nameListArray.removeIf(name->name.length()<6);System.out.println(nameListArray);
		nameListArray.replaceAll(String::toUpperCase);System.out.println(nameListArray);
		
		System.out.println("========================================================================");
		
		final Comparator<Product> priceThenNameThenId=Comparator.comparing(Product::getPrice).thenComparing(Product::getName).thenComparing(Product::getId);
		final Stream<Product> streamSorted=ProductRepository.getInstance().findAll().stream().sorted(priceThenNameThenId);
		streamSorted.forEach(System.out::println);
		final Stream<Product> streamRevSorted=ProductRepository.getInstance().findAll().stream().sorted(priceThenNameThenId.reversed());
		streamRevSorted.forEach(System.out::println);
		
		System.out.println("========================================================================");
		
		final Comparator<String> naturalOrder=Comparator.naturalOrder();
		final Comparator<Product> nullFirst=Comparator.nullsFirst(Comparator.comparing(Product::getPrice));
		final Comparator<Product> nullLast=Comparator.nullsLast(Comparator.comparing(Product::getPrice));
		System.out.println(naturalOrder.toString()+":"+nullFirst.toString()+":"+nullLast);
		
		System.out.println("========================================================================");
		
		final Map<String,Product> itemMap=ProductRepository.getInstance().findAll().stream().collect(Collectors.toMap(Product::getName,(Product product)->product));
		itemMap.forEach((key,value)->System.out.println(key+":"+value));
		System.out.println(itemMap.getOrDefault("Posto",Product.builder().name("Posto").
			id(247119).price(BigDecimal.valueOf(1000d)).inStock(Boolean.TRUE).build()));//Provide Default Value
		
		System.out.println(itemMap.putIfAbsent("AluPosto",Product.builder().name("AluPosto").
			id(247119).price(BigDecimal.valueOf(1000d)).inStock(Boolean.TRUE).build()));//OverWrite If Absent
			
		System.out.println("========================================================================");
	}
}