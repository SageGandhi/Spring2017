package edu.gandhi.prajit.java8.chap01;

@FunctionalInterface // Use For Compiler Checking
public interface FunctionalInterface05 {
	void useFunctionalInterface();

	// These Object Class Methods Does Not Count
	boolean equals(Object obj);

	int hashCode();

	String toString();
	// When Creating A Lambda Expression,Java Virtual Machine Will Create It
	// Without Static/Non-Static Initialization.So Lambda Is An Object Without
	// Own Identity.java.util.function With 43 FunctionalInterface.1.Supplier{Type
	// get()}/2.Consumer{void accept(Type)}/BiConsumer{void accept(Type01,Type02)}/
	//3.Predicate{boolean test(Type)}/BiPredicate{boolean test(Type01,Type02)}/
	//4.Function{ReturnType apply(Type)}/BiFunction{ReturnType apply(Type01,Type02)}
	//UnaryOperator{Type apply(Type)}/BinaryOperator{Type apply(Type,Type)}
}
