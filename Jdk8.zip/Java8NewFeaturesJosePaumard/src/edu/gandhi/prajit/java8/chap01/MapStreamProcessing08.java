package edu.gandhi.prajit.java8.chap01;

import java.util.Arrays;
import java.util.List;
import java.util.function.Function;
import java.util.stream.Stream;

public class MapStreamProcessing08 {
	public static void main(String[] args) throws Exception {
		final List<String> nameList01=Arrays.asList("Prajit", "Gandhi", "Swagat", "Srichandan", "Srabani", "Ghorai");
		final List<String> nameList02=Arrays.asList("Priyani", "Sarkar", "Prakash", "Chandra", "Mahato", "Ravideep", "Singh");
		final List<String> nameList03=Arrays.asList("Supriyo", "Nath", "Suvra","Majumder");
		System.out.println("=============================================================");
		final List<List<String>> allTogether=Arrays.asList(nameList01,nameList02,nameList03);
		allTogether.stream().map(List<String>::stream).forEach(System.out::println);
		System.out.println("=============================================================");
		final Function<List<String>,Stream<String>> listToStreamMapper=list->list.stream();
		allTogether.stream().map(listToStreamMapper).forEach(System.out::println);
		System.out.println("=============================================================");
		/**Flattened All Stream<Type> Into Single Stream*/
		allTogether.stream().flatMap(listToStreamMapper).forEach(System.out::println);
		System.out.println("=============================================================");
	}
}