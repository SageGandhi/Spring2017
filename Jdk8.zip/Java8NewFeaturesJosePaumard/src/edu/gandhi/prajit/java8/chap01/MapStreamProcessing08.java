package edu.gandhi.prajit.java8.chap01;

import java.util.Arrays;
import java.util.List;
import java.util.function.Function;
import java.util.stream.Stream;
import static java.lang.System.out;

public class MapStreamProcessing08 {
	private static final String Separator = "=============================================================";

	public static void main(String[] args) throws Exception {
		final List<String> nameList01=Arrays.asList("Prajit", "Gandhi", "Swagat", "Srichandan", "Srabani", "Ghorai");
		final List<String> nameList02=Arrays.asList("Priyani", "Sarkar", "Prakash", "Chandra", "Mahato", "Ravideep", "Singh");
		final List<String> nameList03=Arrays.asList("Supriyo", "Nath", "Suvra","Majumder");
		out.println(Separator);
		
		final List<List<String>> allTogether=Arrays.asList(nameList01,nameList02,nameList03);
		allTogether.stream().map(List<String>::stream).forEach(out::println);
		out.println(Separator);
		
		final Function<List<String>,Stream<String>> listToStreamMapper=list->list.stream();
		allTogether.stream().map(listToStreamMapper).forEach(out::println);
		out.println(Separator);
		
		/**Flattened All Stream<Type> Into Single Stream*/
		allTogether.stream().flatMap(listToStreamMapper).forEach(out::println);
		out.println(Separator);
		/**
		 * BinaryOperator<T> Extends BiFunction<T,T,T>.It Requires 2 Argument,So
		 * InCase Empty List & List Containing One Element:Returns Identity
		 * Element & Returns Single Element Applied Operation On The Identity.
		 */
		final Stream<Integer> emptyStream=Stream.empty();
		out.println(emptyStream.reduce(0,(item01,item02)->item01+item02));//Sum Operation
		
		final Stream<Integer> singleElementStream=Stream.of(100);
		out.println(singleElementStream.reduce(0,(item01,item02)->item01+item02));//Sum Operation
		
		final Stream<Integer> multiElementStream=Stream.of(100,200,300);
		out.println(multiElementStream.reduce(0,(item01,item02)->item01+item02));//Sum Operation
	}
}