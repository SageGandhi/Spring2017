package edu.gandhi.prajit.java8.chap01;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.function.Consumer;

public class MethodReferenceExample04 {
	public static void main(String[] args) {
		final Consumer<String> sysOutMethodRef=System.out::println;//Instance::Instance Method
		final Comparator<Integer> comparatorMethodRef=Integer::compare;//Class::Static Method
		System.out.println("System.out::println->"+sysOutMethodRef+
			",Integer::compare->"+comparatorMethodRef);
		final List<String> firstList=Arrays.asList("*","***","****","**");
		firstList.forEach(item->System.out.println(item));//Using Lambda
		firstList.forEach(System.out::println);//Using Method Reference
		firstList.forEach(sysOutMethodRef);//Using Method Reference Variable
	}
}
