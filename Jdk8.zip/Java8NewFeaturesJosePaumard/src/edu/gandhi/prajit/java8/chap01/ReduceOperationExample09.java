package edu.gandhi.prajit.java8.chap01;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

public class ReduceOperationExample09 {
	public static void main(String[] args) {
		/**Aggregation Like Reduction[Average,Sum,Min,Max]*/
		final List<String> nameList=Arrays.asList("Prajit", "Gandhi", "Swagat", "Srichandan", "Srabani", "Ghorai",
				"Priyani", "Sarkar", "Prakash", "Chandra", "Mahato", "Ravideep", "Singh", "Supriyo", "Nath", "Suvra",
				"Majumder");
		final Optional<Integer> optional=nameList.stream().map(String::length).reduce((size01,size02)->size01+size02);
		final Integer value=optional.isPresent()?optional.get():0;System.out.println(value);
		
		System.out.println(nameList.stream().map(String::length).reduce(0,(size01,size02)->size01+size02));
		System.out.println(nameList.parallelStream()
			.map(String::length).reduce(0,
				(size01,size02)->size01+size02,
				(size01,size02)->size01+size02));
	}
}