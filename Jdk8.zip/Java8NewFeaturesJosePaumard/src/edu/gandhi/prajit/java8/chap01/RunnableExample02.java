package edu.gandhi.prajit.java8.chap01;

public class RunnableExample02 {
	public static void main(String[] args) throws InterruptedException {
		//Using Anonymous Class
		final Thread thread01=new Thread(new Runnable() {
			@Override
			public void run() {
				for(int loopIndex=0;loopIndex<10;loopIndex++){
					System.out.println("Inside Runnable:"+loopIndex);
					System.out.println(Thread.currentThread().getName());
				}
			}
		});
		//Using Lambda
		final Thread thread02=new Thread(()->{
			for(int loopIndex=0;loopIndex<10;loopIndex++){
				System.out.println("Inside Runnable:"+loopIndex);
				System.out.println(Thread.currentThread().getName());
			}
		});
		thread01.start();
		thread01.join();
		
		thread02.start();
		thread02.join();
	}
}
