package edu.gandhi.prajit.java8.chap01;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Predicate;

public class StreamProcessing07 {
	public static void main(String[] args) {
		/**
		 * 1.Map->Filter->Reduce.Java Typed Interface.2. Stream Can Leverage
		 * MultiCore Automatically. 3.Stream Do Its All Operation In
		 * Pipeline/One Pass.Stream Does Not Hold Any Data,Must Not Change The
		 * Data It[Stream] Process.4.Predicate And,Or,Negate Will Occur As Per
		 * Invocation.5.Stream Operation Are Either InterMediary Operation Or
		 * Final Operation.InterMediary Operation Are Lazy By
		 * Default[Declaration Of An Operation Instead Of Actually Executing It]
		 * And Return Another Stream Object.
		 */
		final List<String> nameList = Arrays.asList("Prajit", "Gandhi", "Swagat", "Srichandan", "Srabani", "Ghorai",
				"Priyani", "Sarkar", "Prakash", "Chandra", "Mahato", "Ravideep", "Singh", "Supriyo", "Nath", "Suvra",
				"Majumder");
		final List<String> filteredList=new ArrayList<>();
		
		final Predicate<String> startWithP=text->text.startsWith("P");
		final Predicate<String> startWithS=text->text.startsWith("S");
		
		final Consumer<String> sysOut=System.out::println;
		final Consumer<String> listAdd=filteredList::add;
		/**All InterMediary Operation,peek & filter Returns Stream<String>.No SysOut Will Be Executed Due To LazyNess.*/
		nameList.stream().peek(sysOut).filter(startWithP.or(startWithS)).peek(filteredList::add);
		filteredList.forEach(sysOut);/**Iterate Through The Filtered List*/
		nameList.stream().filter(startWithP.or(startWithS)).forEach(listAdd.andThen(sysOut));/**Adding Final Operation forEach*/
	}
}