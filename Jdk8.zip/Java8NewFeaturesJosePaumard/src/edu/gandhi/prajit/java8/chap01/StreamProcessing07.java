package edu.gandhi.prajit.java8.chap01;

public class StreamProcessing07 {
	public static void main(String[] args) {
		//Stream Can Leverage MultiCore Automatically
		//Stream Do Its All Operation In Pipeline/One Pass
		//Stream Does Not Hold Any Data,Must Not Change The Data It[Stream] Process.
	}
}