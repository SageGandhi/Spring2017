package edu.gandhi.prajit.java8.chap01;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.StringJoiner;
import static java.lang.System.out;

public class StringJoiner12 {
	public static void main(String[] args) throws Exception {
		final StringJoiner joiner=new StringJoiner(":","{","}");
		try(final BufferedReader bufferedReader=new BufferedReader(new InputStreamReader(AggregationOperation10.class.getResourceAsStream("Input.txt")))){
			bufferedReader.lines().forEach(joiner::add);
		}
		out.println("Using Joiner With Prefix/PostFix:"+joiner.toString());
		out.println(String.join("|","Hello Try With Resources","Hello Try With Resources Using Stream"));
	}
}