package com.pdf.xfa.template.json.helper;

public class EvaluateEnum {
	public static void main(String[] args) throws ClassNotFoundException {
		System.out.println(Enum.valueOf(edu.gandhi.prajit.pdf.pojo.Option.class,"First"));
		System.out.println(Enum.valueOf(edu.gandhi.prajit.pdf.pojo.Option.class,"Second"));
		System.out.println(Enum.valueOf(edu.gandhi.prajit.pdf.pojo.Option.class,"Third"));
	}
}