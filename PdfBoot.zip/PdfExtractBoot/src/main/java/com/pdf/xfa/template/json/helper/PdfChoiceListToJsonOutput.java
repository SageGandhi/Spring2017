package com.pdf.xfa.template.json.helper;

import java.io.InputStream;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.TransformerFactoryConfigurationError;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.itextpdf.forms.PdfAcroForm;
import com.itextpdf.forms.xfa.XfaForm;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfReader;

public class PdfChoiceListToJsonOutput {
	private static final String _ChoiceListTemplatePathDynamic="PdfTemplates\\Sample.pdf";
	private final static ObjectMapper _Mapper=new ObjectMapper();
	public static void main(String[] args) {
		//Handling Xfa Form[Dynamic]
		try(
			final InputStream inputStream=PdfChoiceListToJsonOutput.class.getClassLoader().getResourceAsStream(_ChoiceListTemplatePathDynamic);
			final PdfReader pdfReader = new PdfReader(inputStream);
			final PdfDocument pdfDocument=new PdfDocument(pdfReader);
		){
			final PdfAcroForm pdfAcroForm=PdfAcroForm.getAcroForm(pdfDocument,true);
			if(pdfAcroForm.hasXfaForm()){
				final XfaForm xfaForm=pdfAcroForm.getXfaForm();
				System.out.println("------------------------------------------------------------------------");
				printXfaForm(xfaForm,System.out);//Print To Check Where Values Stored In Pdf
				System.out.println("------------------------------------------------------------------------");
				final Set<String> selectedChoiceListSet=new HashSet<>();
				selectedChoiceListSet.add("ES_001_DDL");
				selectedChoiceListSet.add("OSPServiceDDL");
				selectedChoiceListSet.add("OSPListDDL");
				final Map<String,Object> output=getAllChoiceField(xfaForm,selectedChoiceListSet);
				_Mapper.writer().withDefaultPrettyPrinter().writeValue(System.out,output);				
			}
		}catch (Exception exception) {
			exception.printStackTrace();
		}
	}
	private static Map<String, Object> getAllChoiceField(XfaForm xfaForm,final Set<String> selectedChoiceList) {
		final Map<String,Object> outputMap=new HashMap<>();//Holding All ChoiceList				
		final NodeList allChoiceListNodes=xfaForm.getDomDocument().getElementsByTagName("items");
		for(int index=0;index<allChoiceListNodes.getLength();index++){
			//choiceList[Parent]>ui[Parent]>field
			final Node fieldParent=allChoiceListNodes.item(index).getParentNode();
			//Retrieving Choice List Field Name
			final Node choiceListFieldNameAttrNode=fieldParent.getAttributes().getNamedItem("name");
			final String choiceListName=choiceListFieldNameAttrNode.getNodeValue();
			/*System.out.println("Field Name:"+choiceListFieldNameAttrNode.getNodeValue());*/
			if(!selectedChoiceList.contains(choiceListName))continue;//Skip If Not A DropDown
			
			final Map<String,Object> jsonValueHolder=new HashMap<>();
			//Getting Label & Default Value For The ChoiceList
			final NodeList labelDefaultValueNode=((Element)fieldParent).getElementsByTagName("value");
			/*System.out.println("Label Default Value Node:"+labelDefaultValueNode.getLength());*/
			String labelText=""/*,defaultValueText=""*/;
			//First value Node Is Label,Second One Is For Default Value For ChoiceList 
			for(int labelDefaultIndx=0;labelDefaultIndx<labelDefaultValueNode.getLength();labelDefaultIndx++){
				if(labelDefaultIndx==0) {
					labelText=labelDefaultValueNode.item(labelDefaultIndx).getTextContent();
					/*System.out.println("Label For ChoiceList:"+labelText);*/
					jsonValueHolder.put("labelText",labelText);//Needed To Identify Which One
				}
				if(labelDefaultIndx==1) {
					/*defaultValueText=labelDefaultValueNode.item(labelDefaultIndx).getTextContent();*/
					/*System.out.println("Default Value For ChoiceList:"+defaultValueText);*/
					//Will Not Required To Capture In OutPut Json Map
					/*jsonValueHolder.put("defaultValueText",defaultValueText);*/
				}
			}
			
			//First items Node Is Option Text,Second One Is For Value For ChoiceList Option
			final NodeList itemsNodes=((Element)fieldParent).getElementsByTagName("items");
			final Map<String,Map<String,String>> optionValueTextMap=new HashMap<>();
			if(itemsNodes.getLength()==1) {
				//Only Option Text Is Available
				final NodeList optionTextNodes=((Element)itemsNodes.item(0)).getElementsByTagName("text");
				for(int optTextIndx=0;optTextIndx<optionTextNodes.getLength();optTextIndx++){
					final Map<String,String> optTextValMap=new HashMap<>();
					optTextValMap.put("labelInPdf",optionTextNodes.item(optTextIndx).getTextContent());
					optTextValMap.put("valueInPdf",String.valueOf(optTextIndx));
					optionValueTextMap.put(String.valueOf(optTextIndx),optTextValMap);
					
				}
			}else if(itemsNodes.getLength()==2) {
				//Only Option Text Is Available As Well As Option Value
				final NodeList optionTextNodes=((Element)itemsNodes.item(0)).getElementsByTagName("text");
				final NodeList optionValNodes=((Element)itemsNodes.item(1)).getElementsByTagName("text");
				for(int optTextIndx=0;optTextIndx<optionTextNodes.getLength();optTextIndx++){
					final Map<String,String> optTextValMap=new HashMap<>();
					optTextValMap.put("labelInPdf",optionValNodes.item(optTextIndx).getTextContent());
					optTextValMap.put("valueInPdf",optionTextNodes.item(optTextIndx).getTextContent());
					optionValueTextMap.put(optionTextNodes.item(optTextIndx).getTextContent(),optTextValMap);
				}
			}
			
			jsonValueHolder.put("valueLabelMap",optionValueTextMap);
			outputMap.put(choiceListName,jsonValueHolder);//Name Of The Field With Json PayLoad
			/*System.out.println("Generated Key,Value Map:"+optionValueTextMap);*/
			/*System.out.println("Generated Json PayLoad:"+outputMap);*/
		}
		return outputMap;
	}
	/**
	 * Used For Parsing Xfa Form,Print It,To Examine Node Arrangement
	 * @param xfaForm
	 * @param outputStream
	 */
	private static void printXfaForm(final XfaForm xfaForm,final OutputStream outputStream) {
		try {
			Transformer transformer= TransformerFactory.newInstance().newTransformer();
			transformer.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
			transformer.setOutputProperty(OutputKeys.INDENT, "yes");
			transformer.transform(new DOMSource(xfaForm.getDomDocument()),new StreamResult(outputStream));
		} catch (TransformerFactoryConfigurationError | TransformerException exception) {
			exception.printStackTrace();
		}
	}
}