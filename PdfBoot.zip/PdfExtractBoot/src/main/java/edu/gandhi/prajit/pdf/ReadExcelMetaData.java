package edu.gandhi.prajit.pdf;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Row.MissingCellPolicy;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.util.StringUtils;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class ReadExcelMetaData {
	public final static String _Excel = "DataMapping.xlsx";
	public final static String _Json = "MetaData.json";
	public static void main(String[] args) throws JsonParseException, JsonMappingException, IOException {
		System.out.println("ReadExcelMetaData.main():Start");
		readMetaExcel(_Excel,_Json);
		System.out.println("ReadExcelMetaData.main():End");
	}

	public static Map<String, Map<String, String>> readMetaExcel(String metaExcelPath, String metaJsonPath)
			throws IOException, JsonParseException, JsonMappingException, JsonProcessingException {
		final Map<String,Map<String,String>> _MetaDataMap=new HashMap<>();
		
		String _SheetName = "";
		String _MapKeyColumn="";
		
		int _StartRowIndex=0;
		int _StartCellIndex=0;
		
		final List<String> _ColumnDef = new ArrayList<>();
		final ObjectMapper _Mapper = new ObjectMapper();
		final List<Map<String, Object>> _MetaData = _Mapper.readValue(getResource(metaJsonPath),new TypeReference<List<Map<String, Object>>>(){});

		for (final Map<String, Object> _MetaDataEntry : _MetaData) {
			_SheetName = (String) _MetaDataEntry.get("SheetName");
			_MapKeyColumn=(String) _MetaDataEntry.get("MapKeyColumn");
			
			_StartRowIndex=_MetaDataEntry.containsKey("StartRowIndex")?Integer.valueOf((String)_MetaDataEntry.get("StartRowIndex")):_StartRowIndex;
			_StartCellIndex=_MetaDataEntry.containsKey("StartCellIndex")?Integer.valueOf((String)_MetaDataEntry.get("StartCellIndex")):_StartCellIndex;
			
			final List<Map<String, String>> _ColumnInOrder = _Mapper.convertValue(_MetaDataEntry.get("Columns"),new TypeReference<List<Map<String, String>>>(){});
			for (final Map<String, String> _ColumnIndexedName : _ColumnInOrder) {
				for (final Map.Entry<String, String> _Def : _ColumnIndexedName.entrySet()) {
					System.out.println(_Def.getKey()+":"+_Def.getValue());
					_ColumnDef.add(_Def.getValue());
				}
			}
		}
		
		try (final Workbook workbook = new XSSFWorkbook(getResource(metaExcelPath));) {
			final DataFormatter _Formatter=new DataFormatter();
			final Sheet readSheet = workbook.getSheet(_SheetName);
			final int mapKeyColumnIndex=getMapKeyColumnIndex(_ColumnDef,_MapKeyColumn);//Get Key Column Index

			for(int rowNum = _StartRowIndex/*Skip Header*/; rowNum < readSheet.getLastRowNum(); rowNum++){
				final Row nextRow = readSheet.getRow(rowNum);
				System.out.println("getPhysicalNumberOfRows:"+readSheet.getPhysicalNumberOfRows());
				System.out.println("getLastRowNum:"+readSheet.getLastRowNum());
				System.out.println("getFirstRowNum:"+readSheet.getFirstRowNum());
				if(isEmptyRowNoCellContent(nextRow))continue;//Skip Empty Row At The End May Be
				
				final Map<String,String> cellkeyValue=new HashMap<>();
				String mappedKeyColumnValue=null;//Mapped Key Column Must Not Be Null
				for(int cellIndex=_StartCellIndex;cellIndex<_ColumnDef.size();cellIndex++) {
					final Cell currentCell = nextRow.getCell(cellIndex,MissingCellPolicy.CREATE_NULL_AS_BLANK);
					final String colName = _ColumnDef.get(cellIndex-_StartCellIndex);
					final String cellVal = _Formatter.formatCellValue(currentCell);
					System.out.println(nextRow.getRowNum()+":"+currentCell.getColumnIndex()+":"+cellVal);
					//Cell Index Starts Other Than 0,But _ColumnDef Will Contain No Of Column From 0..
					cellkeyValue.put(colName,cellVal);										
					if(mapKeyColumnIndex==currentCell.getColumnIndex()) {
						mappedKeyColumnValue=cellVal;
					}
				}
				_MetaDataMap.put(mappedKeyColumnValue,cellkeyValue);
			}
		}
		System.out.println(_Mapper.writeValueAsString(_MetaDataMap));
		return _MetaDataMap;
	}

	private static boolean isEmptyRowNoCellContent(Row row) {
	    for (int cellNum = row.getFirstCellNum(); cellNum < row.getLastCellNum(); cellNum++) {
	        Cell cell = row.getCell(cellNum);
	        if (cell != null && cell.getCellTypeEnum() != CellType.BLANK && !StringUtils.isEmpty(cell.toString())) {
	            return false;
	        }
	    }
	    return true;
	}
	public static InputStream getResource(String resource) {
		return ReadExcelMetaData.class.getClassLoader().getResourceAsStream(resource);
	}

	private static int getMapKeyColumnIndex(List<String> _ColumnDef, String _MapKeyColumn) {
		return _ColumnDef.indexOf(_MapKeyColumn);
	}
}
