package com.aig.pdf.export;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PdfExporterServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(PdfExporterServiceApplication.class, args);
	}
}
