package com.aig.pdf.export.resources;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("/PdfFieldValueExporter")
@Api(value = "Api For Pdf Form Data Export")
public class PdfFieldValueExporter {
	@GetMapping(value="/Version",
		produces={MediaType.APPLICATION_JSON_VALUE,MediaType.APPLICATION_XML_VALUE},
		consumes={MediaType.APPLICATION_JSON_VALUE,MediaType.APPLICATION_XML_VALUE})
	@ApiOperation(value = "Get Pdf Exporter Api Version", notes = "Get Pdf Exporter Api Version", nickname = "ApiVersion")
	public String getVersion(){
		return "Api.Version.01";
	}	
}