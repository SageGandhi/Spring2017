package com.aig.pdf.export;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class PdfExporterServiceApplicationTests {

	@Test
	public void contextLoads() {
	}

}
